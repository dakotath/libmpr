var searchData=
[
  ['entry_0',['Entry',['../struct_entry.html',1,'']]]
];
