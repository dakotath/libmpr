var searchData=
[
  ['allocateclearedmemory_0',['allocateClearedMemory',['../memory_8c.html#a1186135cd895e2b583fb09ebea779748',1,'memory.c']]],
  ['allocatememory_1',['allocateMemory',['../memory_8c.html#a4a1689c40ab31d1426e7ab3862859093',1,'memory.c']]],
  ['allocatememoryalligned_2',['allocateMemoryAlligned',['../memory_8c.html#a4c86986f697781c5de782ab1b1c75286',1,'memory.c']]]
];
