var searchData=
[
  ['size_0',['Size',['../struct_size.html',1,'']]]
];
