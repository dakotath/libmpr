var searchData=
[
  ['ticks_5fto_5fmillisecs_0',['ticks_to_millisecs',['../moviegif_8c.html#a46ffc43119318a53a3021fc094a11f68',1,'moviegif.c']]]
];
