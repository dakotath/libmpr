var searchData=
[
  ['updatewindow_0',['updateWindow',['../core_8c.html#a6ff50275544a950c852f81399b0441d3',1,'core.c']]]
];
