var searchData=
[
  ['fillscreen_0',['fillScreen',['../core_8c.html#a3a307acc9dd50e7ade80f025f63dda1f',1,'core.c']]],
  ['freememory_1',['freeMemory',['../memory_8c.html#a6a1a10ce3514d99b5805d67af8e058a5',1,'memory.c']]]
];
