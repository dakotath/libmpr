var searchData=
[
  ['moviegif_5fcreatemoviefromfiles_0',['MovieGif_CreateMovieFromFiles',['../moviegif_8c.html#ad8d662218c1b4215c577eaa2d99dd6b4',1,'MovieGif_CreateMovieFromFiles(char *gifFile, char *audioFile, char *outputFile, uint8_t audiotype, uint16_t audio_bitrate, uint8_t audio_channels):&#160;moviegif.c'],['../moviegif_8h.html#ad8d662218c1b4215c577eaa2d99dd6b4',1,'MovieGif_CreateMovieFromFiles(char *gifFile, char *audioFile, char *outputFile, uint8_t audiotype, uint16_t audio_bitrate, uint8_t audio_channels):&#160;moviegif.c']]],
  ['moviegif_5ftestplayback_1',['MovieGif_TestPlayback',['../moviegif_8c.html#aafa2f0a7534bc23beb5a4c71d29b9851',1,'MovieGif_TestPlayback(Window win, MovieGif_t movie):&#160;moviegif.c'],['../moviegif_8h.html#aafa2f0a7534bc23beb5a4c71d29b9851',1,'MovieGif_TestPlayback(Window win, MovieGif_t movie):&#160;moviegif.c']]]
];
