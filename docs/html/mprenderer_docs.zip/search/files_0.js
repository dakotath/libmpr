var searchData=
[
  ['core_2ec_0',['core.c',['../core_8c.html',1,'']]]
];
