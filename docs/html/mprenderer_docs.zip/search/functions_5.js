var searchData=
[
  ['getavailablememory_0',['getAvailableMemory',['../memory_8c.html#a9a723e225ee9135d40b23317e3a92892',1,'memory.c']]],
  ['gettextwidthttf_1',['getTextWidthTTF',['../core_8c.html#aca5519e5f3aa3f7ad92ae4815ea1b5b8',1,'core.c']]],
  ['getusedmemory_2',['getUsedMemory',['../memory_8c.html#a7b98d9f8a6b22fb76bbb2688ac70a39d',1,'memory.c']]]
];
